/*
Write a JavaScript function to get the function name.
*/
