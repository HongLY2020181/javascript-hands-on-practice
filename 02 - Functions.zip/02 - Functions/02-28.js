/*
Write a JavaScript program to pass a 'JavaScript function' as parameter.
*/

