/*
Write a JavaScript function to find longest substring in a given a string without repeating characters.
*/